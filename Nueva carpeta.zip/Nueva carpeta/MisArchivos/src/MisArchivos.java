import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class MisArchivos {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        FileWriter fileWriter = null;
        BufferedWriter bufferedWriter = null;
        int contadorCadenas = 1;
        try {
        	
            fileWriter = new FileWriter("C:/Users/6002508/misArchivos/log.txt");
            bufferedWriter = new BufferedWriter(fileWriter);

            System.out.println("Ingrese las cadenas de caracteres nº " + contadorCadenas + " (escriba 'fin' para finalizar):");
            while (!(input = scanner.nextLine()).equals("fin")) {
                bufferedWriter.write(input);
                bufferedWriter.newLine();
                contadorCadenas++;
                System.out.println("Ingrese las cadenas de caracteres nº " + contadorCadenas + " (escriba 'fin' para finalizar):");
            }
            System.out.println("Ha escrito " + contadorCadenas + " y se han almacenado en su escritorio, en la carpeta misArchivos");

        } catch (IOException e) {
        	
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        } finally {
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (IOException e) {
                System.out.println("Error al cerrar el archivo: " + e.getMessage());
            }
        }

        BufferedReader entrada = null;
        try {
            entrada = new BufferedReader(new FileReader("C:/Users/6002508/misArchivos/log.txt"));
            String cadena;
            while ((cadena = entrada.readLine()) != null) {
                System.out.println(cadena);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
            	
                if (entrada != null) {
                    entrada.close();
                }
            } catch (IOException e) {
                System.out.println("Error al cerrar el archivo: " + e.getMessage());
            }
        }
    }
            }



