public class TorneoException extends RuntimeException {

    public TorneoException(String mensaje) {
        super(mensaje);
    }

}