package tanques.exceptions;

public class TanqueLlenoException extends SecurityException {
	public TanqueLlenoException(String msg) {
		super(msg);
	}
}
