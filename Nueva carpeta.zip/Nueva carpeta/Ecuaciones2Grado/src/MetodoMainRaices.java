
public class MetodoMainRaices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Raices ecuacion=new Raices(2,5,-3);
     ecuacion.calcular();
     Raices ecuacion2 = new Raices(1,4,4);
     ecuacion2.calcular();
	}

}
