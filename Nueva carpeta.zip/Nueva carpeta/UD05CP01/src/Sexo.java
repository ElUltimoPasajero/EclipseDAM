
public enum Sexo {
	Hombre, Mujer
}
