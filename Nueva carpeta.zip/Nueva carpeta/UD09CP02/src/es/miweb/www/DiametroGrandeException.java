package es.miweb.www;

public class DiametroGrandeException extends Exception{
	public DiametroGrandeException(String cadena){
		super(cadena);
	}
}
