package es.miweb.www;

public class DiametroPequenoException extends Exception {
	public DiametroPequenoException(String cadena){
		super(cadena);
	}
}
