
public class Sistema {
	
	String [] planetas;

}
