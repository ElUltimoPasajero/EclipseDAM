
public class Bucle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=3;
      for(i=0; i<10; i++) {
    	  
    	  if (i>=5 && i<=7) {
    		  
    		  continue;
    		 
    	  }
    	  
    	  
    	  
    	  System.out.println(i);
      }
      
      
      
	
	
	
	}

}
