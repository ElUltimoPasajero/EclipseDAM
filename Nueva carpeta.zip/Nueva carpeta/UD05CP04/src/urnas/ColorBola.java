package urnas;

public enum ColorBola {
    BLANCA, NEGRA
}