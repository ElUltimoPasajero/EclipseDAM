
public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String paises [] = {"Colombia","Peru","Mexico","Ecuador","España"};
		
		
		
		for (int i = 0; i < paises.length; i++) {
			
			System.out.println(paises[i]);
		}
		
		
	}

}
