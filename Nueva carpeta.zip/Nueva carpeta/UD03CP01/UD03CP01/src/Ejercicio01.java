import java.util.Scanner;

public class Ejercicio01 {
	public static void main(String[] args) {
		for (int fila = 0; fila < 10; fila++) {
			for (int i = 0; i <= fila; i++) {
				System.out.print(i+",");
			}
			System.out.println("");
		}
	}
}
