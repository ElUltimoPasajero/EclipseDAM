
public class Ejercicio03 {

	public static void main(String[] args) {
		for (int fila = 1; fila < 10; fila++) {
			for (int i = 1; i <= fila; i++) {
				System.out.print(fila+",");
			}
			System.out.println("");
		}
	}

}
