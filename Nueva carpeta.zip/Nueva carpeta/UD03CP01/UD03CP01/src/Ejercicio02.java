
public class Ejercicio02 {

	public static void main(String[] args) {
		for (int fila = 0; fila < 10; fila++) {
			for (int i = fila; i < 10; i++) {
				System.out.print(i+",");
			}
			System.out.println("");
		}
	}

}
