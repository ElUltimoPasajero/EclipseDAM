
public class Matriz {
	
	
	private int [][]matriz;
	

	
	public Matriz(int tamaño) {
		
		this.matriz = matriz;
	}


	public int[][] getMatriz() {
		return matriz;
	}


	public void setMatriz(int[][] matriz) {
		matriz = matriz;
	}


	public void asignarDatos(int[] vector) {
		
		int tamaño= (int) Math.sqrt(vector.length);
		
		int indiceVector=0;
		
		matriz= new int [tamaño][tamaño];
		
		for (int i = 0; i < matriz.length; i++) {
			
			for (int j = 0; j < matriz.length; j++) {
				
				matriz[i][j]=vector[indiceVector];
				
				indiceVector++;
				
				
			}
			
		}
		
		
	}
	
	
	public void suma(Matriz m) {
		
		
		
		
	}

}
