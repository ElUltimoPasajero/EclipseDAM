
public class TestMatriz {

	public static void main(String[] args) {
		Matriz m = new Matriz(3);
		Matriz n = new Matriz(3);
           
		int[] vector = {3, 2, 1, 1, 2, 3, 2, 3, 1};
		m.asignarDatos(vector);
		
		int[] vector2 = {1, 1, 2, 2, 1, 1, 1, 2, 1};
		n.asignarDatos(vector2);

		
		for (int i = 0; i < vector2.length; i++) {
			
			for (int j = 0; j < vector.length; j++) {
				
				System.out.print(vector2[i]+vector[j]+ " ");

			}
			
			System.out.println();
			
			
		}
	    }
	
		
	}
	
	


