package Practica02ud06.Vehiculos;

public enum Color {
	BLANCO, NEGRO, GRIS, ROJO, AZUL
}
