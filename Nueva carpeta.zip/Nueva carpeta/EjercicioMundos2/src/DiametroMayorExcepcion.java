class DiametroMayorExcepcion extends Exception {
    public DiametroMayorExcepcion(String mensaje) {
        super(mensaje);
    }
}