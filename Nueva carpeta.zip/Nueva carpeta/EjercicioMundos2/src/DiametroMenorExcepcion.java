class DiametroMenorExcepcion extends Exception {
    public DiametroMenorExcepcion(String mensaje) {
        super(mensaje);
    }
}