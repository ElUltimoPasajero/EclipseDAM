
public enum Sexo { HOMBRE,MUJER
	
	

}
