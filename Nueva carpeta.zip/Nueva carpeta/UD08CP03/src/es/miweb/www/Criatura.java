package es.miweb.www;

import java.util.Random;

public abstract class Criatura {
	private int vidaMaxima;
	private int vidaActual;
	private int fuerza;
	private String nombre;

	/**
	 * Constructor de la clase Criatura
	 * 
	 * @param nombre
	 * @param vida
	 * @param fuerza
	 * 
	 *            Se asigna el mismo valor a vidaActual y a vidaMaxima
	 */
	public Criatura(String nombre, int vida, int fuerza) {
		this.nombre = nombre;
		this.vidaActual = vida;
		this.fuerza = fuerza;
		this.vidaMaxima = vida;
	}

	/*
	 * Implementaci�n de los getters y setters
	 */
	public int getVidaMaxima() {
		return vidaMaxima;
	}

	public void setVidaMaxima(int vidaMaxima) {
		this.vidaMaxima = vidaMaxima;
	}

	public int getVidaActual() {
		return vidaActual;
	}

	public void setVidaActual(int vidaActual) {
		this.vidaActual = vidaActual;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Método luchar: implementa la lucha de una Criatura con otra A la Criatura
	 * que se "ataca" se le resta de su vidaActual la fuerza de la Criatura que
	 * le "ataca" Si una de las Criaturas muere se le asigna el valor -1 para
	 * que cuando est� en "recuperaci�n" consiga f�cilmente algo de vida
	 * 
	 * @param c
	 */
	public void luchar(Criatura c) {
		Random rnd = new Random();
		while ((this.getVidaActual() >= 0) && (c.getVidaActual() >= 0)) {
			if ((c.getVidaActual() >= 0) && (this.getVidaActual() >= 0)) {
				float turno = rnd.nextInt(c.getVidaActual() + this.getVidaActual()) + 1;
				if (turno == 1.0F) {
					this.descansar();
					c.descansar();
				} else if (turno < this.getVidaActual()) {
					System.out.println(this.getNombre() + " pega a " + c.getNombre());
					// Compruebo si el resultado es negativo para asignarle -1
					if ((c.getVidaActual() - this.getFuerza()) < 1) {
						c.setVidaActual(-1);
						System.out.println(c.getNombre() + " ha muerto");
					} else {
						c.setVidaActual(c.getVidaActual() - this.getFuerza());
						if (c.getVidaActual() < 5) {
							System.out.println("El golpe a " + c.getNombre() + " ha sido cr�tico!!");
						}
					}
				} else if (turno > this.getVidaActual()) {
					System.out.println(c.getNombre() + " pega a " + this.getNombre());
					// Compruebo si el resultado es negativo para asignarle -1
					if ((this.getVidaActual() - c.getFuerza()) < 1) {
						this.setVidaActual(-1);
						System.out.println(this.getNombre() + " ha muerto");
					} else {
						this.setVidaActual(this.getVidaActual() - c.getFuerza());
						if (this.getVidaActual() < 5) {
							System.out.println("El golpe a " + this.getNombre() + " ha sido cr�tico!!");
						}
					}

				} else {
					if (this.getVidaActual() < this.getVidaMaxima())
						this.recuperar();
					if (c.getVidaActual() < c.getVidaMaxima())
						c.recuperar();
				}
			}

			if (c.getVidaActual() < 0) {
				System.out.println(this.getNombre() + " no puede pegarle a " + c.getNombre() + " porque est� muerto");
			} else if (this.getVidaActual() < 0) {
				System.out.println(this.getNombre() + " est� muerto y no le puede pegar a " + c.getNombre());
			}
		}
	}

	/**
	 * M�todo recuperar: La Criatura recupera un valor aleatorio de vida que se
	 * le suma a su vidaActual
	 */
	public void recuperar() {
		if (this.getVidaActual() >= 0) {
			Random r = new Random();
			int incremento = r.nextInt(this.vidaMaxima + 1);
			if ((incremento + this.vidaActual) > this.vidaMaxima) {
				this.vidaActual = this.vidaMaxima;
			} else {
				this.vidaActual += incremento;
			}
			System.out.println(this.getNombre() + " se est� recuperando");
		} else {
			System.out.println(this.getNombre() + " no puede recuperarse.Est� muerto");
		}
	}

	/**
	 * M�todo descansar: La Criatura recupera su vidaMaxima
	 */
	public void descansar() {
		if (this.getVidaActual() >= 0) {
			this.vidaActual = this.vidaMaxima;
			System.out.println(this.getNombre() + " est� descansando");
		} else {
			System.out.println(this.getNombre() + " no puede descansar. Est� muerto");
		}
	}

	/**
	 * M�todo toString: Se reescribe el m�todo para que muestre las
	 * caracter�sticas de la Criatura
	 */
	public String toString() {
		return this.nombre + " Vida M�xima: " + this.getVidaMaxima() + " Fuerza: " + this.getFuerza() + " Vida actual: "
				+ this.getVidaActual();
	}

}
