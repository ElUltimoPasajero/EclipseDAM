package es.miweb.www;

public class Enano extends Criatura {
	public static final int VIDAMAX_ENANO = 10;
	public static final int FUERZA_ENANO = 10;

	/**
	 * Constructor de la clase Enano
	 * 
	 * @param nombre
	 */
	public Enano(String nombre) {
		super(nombre, VIDAMAX_ENANO, FUERZA_ENANO);

	}
}
