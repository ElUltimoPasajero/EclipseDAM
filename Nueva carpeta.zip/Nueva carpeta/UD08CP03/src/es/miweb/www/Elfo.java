package es.miweb.www;

public class Elfo extends Criatura {
	public static final int VIDAMAX_ELFO = 20;
	public static final int FUERZA_ELFO = 3;

	/**
	 * Constructor de la clase Elfo
	 * 
	 * @param nombre
	 */
	public Elfo(String nombre) {
		super(nombre, VIDAMAX_ELFO, FUERZA_ELFO);

	}
}
