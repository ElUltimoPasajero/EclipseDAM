package es.miweb.www;

public class Trol extends Criatura {
	public static final int VIDAMAX_TROL = 14;
	public static final int FUERZA_TROL = 5;

	/**
	 * Constructor de la clase Trol
	 * 
	 * @param nombre
	 */
	public Trol(String nombre) {
		super(nombre, VIDAMAX_TROL, FUERZA_TROL);

	}
}
