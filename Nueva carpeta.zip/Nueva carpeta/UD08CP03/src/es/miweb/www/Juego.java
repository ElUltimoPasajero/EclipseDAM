package es.miweb.www;

public class Juego {

	public static void imprimeEstado(int numPelea, Criatura... criaturas) {
		System.out.println("\nResultado de la pelea " + numPelea);
		System.out.println("-----------------------");
		for (Criatura c : criaturas) {
			System.out.println(c.toString());
		}
	}

	public static void main(String[] args) {
		Enano enano1 = new Enano("Enano1");
		Elfo elfo1 = new Elfo("Elfo1");
		Trol trol1 = new Trol("Trol1");

		// //Primera pelea
		// System.out.println("PELEA 1");
		// System.out.println("=======");
		// enano1.luchar(trol1);
		// elfo1.luchar(trol1);
		// trol1.recuperar();
		//
		// imprimeEstado(1,enano1,elfo1,trol1);
		//
		//
		// //Segunda pelea
		// System.out.println("\n\nPELEA 2");
		// System.out.println("=======");
		// elfo1.luchar(enano1);
		// enano1.recuperar();
		// trol1.recuperar();
		// elfo1.luchar(trol1);
		//
		// imprimeEstado(2,enano1,elfo1,trol1);
		//
		// //Tercera pelea
		// System.out.println("\n\nPELEA 3");
		// System.out.println("=======");
		// enano1.luchar(trol1);
		// trol1.luchar(elfo1);
		// elfo1.recuperar();
		//
		// imprimeEstado(3,enano1,elfo1,trol1);
		//
		// //Cuarta pelea
		// System.out.println("\n\nPELEA 4");
		// System.out.println("=======");
		// enano1.luchar(trol1);
		// elfo1.luchar(enano1);
		// trol1.luchar(elfo1);
		// trol1.recuperar();
		//
		// imprimeEstado(4,enano1,elfo1,trol1);
		//
		// //Quinta pelea
		// System.out.println("\n\nPELEA 5");
		// System.out.println("=======");
		// enano1.luchar(elfo1);
		// elfo1.luchar(enano1);
		// trol1.luchar(enano1);
		// enano1.descansar();
		//
		// imprimeEstado(5,enano1,elfo1,trol1);

		// Primera pelea
		System.out.println("PELEA 1");
		System.out.println("=======");
		System.out.println("Enano contra Trol");
		System.out.println("=================");
		enano1.luchar(trol1);

		imprimeEstado(1, enano1, trol1);
		System.out.println();
		System.out.println("====================");
		System.out.println("Vencedor contra Elfo");
		System.out.println("====================");

		if (enano1.getVidaActual() > 0) {
			elfo1.luchar(enano1);
			imprimeEstado(1, enano1, elfo1);
		} else {
			elfo1.luchar(trol1);
			imprimeEstado(1, elfo1, trol1);
		}
	}

}
