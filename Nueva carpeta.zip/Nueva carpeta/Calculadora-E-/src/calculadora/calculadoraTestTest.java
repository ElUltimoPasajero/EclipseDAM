package calculadora;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class calculadoraTestTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
