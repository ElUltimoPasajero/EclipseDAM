package es.miweb.www;

public class DemasiadoCalor extends Limites{
	public DemasiadoCalor(){
		super("Demasiado Calor");
	}
}
