package es.miweb.www;

public class DemasiadoFrio extends Limites{
	public DemasiadoFrio(){
		super("Demasiado Frio");
	}
}
