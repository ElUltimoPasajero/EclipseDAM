package es.miweb.www;

public class TestDivisionPorCero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Practica Excepciones 1 - Divido por cero");
		DivisionPorCero dpc = new DivisionPorCero();
		dpc.division(34,0);
		System.out.println("\tVolviendo de main");
	}

}
