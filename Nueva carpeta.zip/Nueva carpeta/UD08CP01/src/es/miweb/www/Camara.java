package es.miweb.www;

public interface Camara {

	public abstract void sacarFoto(int resolucion);
}
