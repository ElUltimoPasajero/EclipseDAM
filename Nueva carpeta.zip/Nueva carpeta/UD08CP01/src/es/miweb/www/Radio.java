package es.miweb.www;

public interface Radio {
	
	public abstract void escucharSintonia(String sintonia);
}
