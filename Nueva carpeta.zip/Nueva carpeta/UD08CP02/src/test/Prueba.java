package test;

import fechas.Fecha;
import fechas.FechaConDiaSemana;

public class Prueba {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FechaConDiaSemana miFcds = new FechaConDiaSemana(19,3,2020);
		System.out.println(miFcds);
		miFcds.setDia(1);
		miFcds.setMes(5);
		System.out.print("El primer domingo de mayo de 2020 es el ");
		while (miFcds.getDiaSemana()!=6){
			miFcds.diaSiguiente();
		}
		System.out.println(miFcds);
		
		System.out.println("DIFERENCIA:"+miFcds.diferenciaDeDiasCon(new Fecha(1,1,2021))+" dias");
		FechaConDiaSemana miFcds1 = new FechaConDiaSemana(19,3,1625);
		System.out.println("Dias transcurridos desde el "+miFcds1+ " hasta el "+miFcds+":"+Math.abs(miFcds.diferenciaDeDiasCon(new Fecha(miFcds1.getDia(),miFcds1.getMes(),miFcds1.getAnho()))));
		
		miFcds.trasladar(1000);
		System.out.println(miFcds);		
	}

}
