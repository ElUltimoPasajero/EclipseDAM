package fechas;

public class FechaConDiaSemana extends Fecha{
	public static final Fecha LUNES=new Fecha(24,3,2003);
	private int diaSemana;

	public FechaConDiaSemana(int dia,int mes,int anho){
		super(dia,mes,anho);
		this.setDiaSemana(this.calculaDiaSemana());
	}
	
	public void setDia(int dia){
		super.setDia(dia);
		this.setDiaSemana(this.calculaDiaSemana());
	}
	
	public void setMes(int mes){
		super.setMes(mes);
		this.setDiaSemana(this.calculaDiaSemana());
	}
	
	public void setAnho(int anho){
		super.setAnho(anho);
		this.setDiaSemana(this.calculaDiaSemana());
	}
	
	public int getDiaSemana() {
		return diaSemana;
	}

	public void setDiaSemana(int diaSemana) {
		this.diaSemana = diaSemana;
	}
	
	public int calculaDiaSemana(){
		int numDias;
		numDias=LUNES.diferenciaDeDiasCon(this);
		if (numDias<0)
			return Math.abs((numDias%7)+7);
		else
			return numDias%7;
	}
	
	public void trasladar(int ndias){
		super.trasladar(ndias);
		this.setDiaSemana(this.calculaDiaSemana());
	}
	
	public void diaSiguiente(){
		this.trasladar(1);
	}
	
	public void diaAnterior(){
		this.trasladar(-1);
	}
	
	public String queDiaSemana(int dia){
		String cadena="";
		switch (dia){
			case 0: cadena="Lunes";break; 
			case 1: cadena="Martes";break;
			case 2: cadena="Mi�rcoles";break;
			case 3: cadena="Jueves";break;
			case 4: cadena="Viernes";break;
			case 5: cadena="S�bado";break;
			case 6: cadena="Domingo";break;
		}
		return cadena;
	}
	
	@Override
	public Fecha clone(){
		return new FechaConDiaSemana(this.getDia(),this.getMes(),this.getAnho());
	}
	
	@Override
	public String toString(){
		return super.toString()+" "+this.queDiaSemana(this.calculaDiaSemana());
	}
}
