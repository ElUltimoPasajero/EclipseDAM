
public class NoDivisibleEntreUnoException extends Exception{
	
	
	public NoDivisibleEntreUnoException() {
		
		super("Lo siento, no se puede dividir por cero");
		
		
	}

}
