import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class RectanguloTest {

	@BeforeAll
	static void setUpBeforeClass() {
		System.out.println("Setup for test complete.");

		
	}

	@AfterAll
	static void tearDownAfterClass()  {
        System.out.println("Test complete");	

	}
		
	    @Test
	    public void test1() {
	    	
	        Rectangulo rectangulo = new Rectangulo();
	        assertEquals(0, rectangulo.getH());
	        assertEquals(0, rectangulo.getW());
	        System.out.println("Test 1 completed successfully.");
	    }
	    
	    @Test
	    public void test2() {
	    	
	    	Rectangulo rectangulo = new Rectangulo();

	        assertEquals(0, rectangulo.getH());
	        assertEquals(0, rectangulo.getW());
	        assertEquals(0, rectangulo.getA());
	        
	        System.out.println("Test 2 completed successfully.");
	    }

	    	
	    @Test
	    public void test3() {
	    	Rectangulo rect = new Rectangulo(10, 20);
	        assertEquals(10, rect.getH());
	        assertEquals(20, rect.getW());
	        assertEquals(200, rect.getA());
	        System.out.println("Test 3 completed successfully.");
	    }
	   
	        @Test
	        public void test4() {
	        	Rectangulo[] rectangulos = new Rectangulo[5];

	            rectangulos[0] = new Rectangulo();
	            rectangulos[1] = new Rectangulo(2, 3);
	            rectangulos[2] = new Rectangulo(4, 6);
	            rectangulos[3] = new Rectangulo(6, 9);
	            rectangulos[4] = new Rectangulo(8, 12);

	            assertEquals(0, rectangulos[0].getH());
	            assertEquals(0, rectangulos[0].getW());
	            assertEquals(0, rectangulos[0].getA());

	            assertEquals(2, rectangulos[1].getH());
	            assertEquals(3, rectangulos[1].getW());
	            assertEquals(6, rectangulos[1].getA());

	            assertEquals(4, rectangulos[2].getH());
	            assertEquals(6, rectangulos[2].getW());
	            assertEquals(24, rectangulos[2].getA());

	            assertEquals(6, rectangulos[3].getH());
	            assertEquals(9, rectangulos[3].getW());
	            assertEquals(54, rectangulos[3].getA());

	            assertEquals(8, rectangulos[4].getH());
	            assertEquals(12, rectangulos[4].getW());
	            assertEquals(96, rectangulos[4].getA());

	            System.out.println("Test 4 completed successfully.");
	        }
	        
	        
	        @Test
	        public void test5() {
	        	Rectangulo[] rectangulos = new Rectangulo[5];

	            rectangulos[0] = new Rectangulo();
	            rectangulos[1] = new Rectangulo(11, 7);
	            rectangulos[2] = new Rectangulo(22, 14);
	            rectangulos[3] = new Rectangulo(33, 21);
	            rectangulos[4] = new Rectangulo(44, 28);

	            assertEquals(0, rectangulos[0].getH());
	            assertEquals(0, rectangulos[0].getW());
	            assertEquals(0, rectangulos[0].getA());

	            assertEquals(11, rectangulos[1].getH());
	            assertEquals(7, rectangulos[1].getW());
	            assertEquals(77, rectangulos[1].getA());

	            assertEquals(22, rectangulos[2].getH());
	            assertEquals(14, rectangulos[2].getW());
	            assertEquals(308, rectangulos[2].getA());

	            assertEquals(33, rectangulos[3].getH());
	            assertEquals(21, rectangulos[3].getW());
	            assertEquals(693, rectangulos[3].getA());

	            assertEquals(44, rectangulos[4].getH());
	            assertEquals(28, rectangulos[4].getW());
	            assertEquals(1232, rectangulos[4].getA());

	            System.out.println("Test 5 completed successfully.");
	        }
	        
	        @Test
	        public void test6() {
	        	Rectangulo[] rectangulos = new Rectangulo[5];

	            rectangulos[0] = new Rectangulo();
	            rectangulos[1] = new Rectangulo(11, 7);
	            rectangulos[2] = new Rectangulo(22, 14);
	            rectangulos[3] = new Rectangulo(33, 21);
	            rectangulos[4] = new Rectangulo(44, 28);

	            for (Rectangulo rectangle : rectangulos) {
	                System.out.println(rectangle.toString());
	            }

	            System.out.println("Test 6 completed successfully.");
	            
	        }
	   
	        	
	        }
	    
	        
	    
	    


