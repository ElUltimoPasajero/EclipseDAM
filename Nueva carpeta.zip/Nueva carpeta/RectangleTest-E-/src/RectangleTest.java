import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;

import static org.junit.Assert.assertEquals;



public class RectangleTest {
	
	@BeforeAll
	static void init() {
		
		System.out.println("Setup for test complete.");
		
		
	}
	
    @Test
    public void test1() {
    	
        Rectangle rectangulo = new Rectangle();
        assertEquals(0, rectangulo.getH());
        assertEquals(0, rectangulo.getW());
        System.out.println("Test 1 completed successfully.");
    }
    
    @Test
    public void test2() {
    	
        Rectangle rectangulo = new Rectangle();

        assertEquals(0, rectangulo.getH());
        assertEquals(0, rectangulo.getW());
        assertEquals(0, rectangulo.getA());
        
        System.out.println("Test 2 completed successfully.");
    }

    	
    @Test
    public void test3() {
        Rectangle rect = new Rectangle(10, 20);
        assertEquals(10, rect.getH());
        assertEquals(20, rect.getW());
        assertEquals(200, rect.getA());
        System.out.println("Test 3 completed successfully.");
    }
   
        @Test
        public void test4() {
            Rectangle[] rectangulos = new Rectangle[5];

            rectangulos[0] = new Rectangle();
            rectangulos[1] = new Rectangle(2, 3);
            rectangulos[2] = new Rectangle(4, 6);
            rectangulos[3] = new Rectangle(6, 9);
            rectangulos[4] = new Rectangle(8, 12);

            assertEquals(0, rectangulos[0].getH());
            assertEquals(0, rectangulos[0].getW());
            assertEquals(0, rectangulos[0].getA());

            assertEquals(2, rectangulos[1].getH());
            assertEquals(3, rectangulos[1].getW());
            assertEquals(6, rectangulos[1].getA());

            assertEquals(4, rectangulos[2].getH());
            assertEquals(6, rectangulos[2].getW());
            assertEquals(24, rectangulos[2].getA());

            assertEquals(6, rectangulos[3].getH());
            assertEquals(9, rectangulos[3].getW());
            assertEquals(54, rectangulos[3].getA());

            assertEquals(8, rectangulos[4].getH());
            assertEquals(12, rectangulos[4].getW());
            assertEquals(96, rectangulos[4].getA());

            System.out.println("Test 4 completed successfully.");
        }
        
        
        @Test
        public void test5() {
            Rectangle[] rectangulos = new Rectangle[5];

            rectangulos[0] = new Rectangle();
            rectangulos[1] = new Rectangle(11, 7);
            rectangulos[2] = new Rectangle(22, 14);
            rectangulos[3] = new Rectangle(33, 21);
            rectangulos[4] = new Rectangle(44, 28);

            assertEquals(0, rectangulos[0].getH());
            assertEquals(0, rectangulos[0].getW());
            assertEquals(0, rectangulos[0].getA());

            assertEquals(11, rectangulos[1].getH());
            assertEquals(7, rectangulos[1].getW());
            assertEquals(77, rectangulos[1].getA());

            assertEquals(22, rectangulos[2].getH());
            assertEquals(14, rectangulos[2].getW());
            assertEquals(308, rectangulos[2].getA());

            assertEquals(33, rectangulos[3].getH());
            assertEquals(21, rectangulos[3].getW());
            assertEquals(693, rectangulos[3].getA());

            assertEquals(44, rectangulos[4].getH());
            assertEquals(28, rectangulos[4].getW());
            assertEquals(1232, rectangulos[4].getA());

            System.out.println("Test 5 completed successfully.");
        }
        
        @Test
        public void test6() {
            Rectangle[] rectangulos = new Rectangle[5];

            rectangulos[0] = new Rectangle();
            rectangulos[1] = new Rectangle(11, 7);
            rectangulos[2] = new Rectangle(22, 14);
            rectangulos[3] = new Rectangle(33, 21);
            rectangulos[4] = new Rectangle(44, 28);

            for (Rectangle rectangle : rectangulos) {
                System.out.println(rectangle.toString());
            }

            System.out.println("Test 6 completed successfully.");
            
        }
        
        @AfterEach
  	     public  void nada() {
        	
        }
  	  
    
        @AfterAll
        static void close() {
        	
        System.out.println("Test complete");	
        	
        }
    }
        
    
    

    	
    	
    	
    
    
    
