public enum Color {
	blanco, negro, rojo, azul, gris
}
