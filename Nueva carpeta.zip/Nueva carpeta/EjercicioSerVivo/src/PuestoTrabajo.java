
public class PuestoTrabajo {
	
	private String codigo;
	private double sueldoBruto;
	

}
